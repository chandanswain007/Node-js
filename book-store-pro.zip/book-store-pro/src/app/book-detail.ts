import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DatePipe, CurrencyPipe } from '@angular/common';
import { DiscountPipe } from './discount.pipe';
import { Book } from './data';

@Component({
  selector: 'app-book-detail',
  standalone: true,
  imports: [CommonModule, DatePipe, CurrencyPipe, DiscountPipe],
  templateUrl: './book-detail.html',
  styleUrls: ['./book-detail.css']
})
export class BookDetailComponent {
  @Input() book!: Book;
}