import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Book, DataService } from './data';
import { Subscription } from 'rxjs';
import { DiscountPipe } from './discount.pipe';
import { DatePipe, CurrencyPipe, UpperCasePipe, SlicePipe } from '@angular/common';
import { BookDetailComponent } from './book-detail';

@Component({
  selector: 'app-book',
  standalone: true,
  imports: [
    CommonModule,
    DatePipe,
    CurrencyPipe,
    UpperCasePipe,
    SlicePipe,
    DiscountPipe,
    BookDetailComponent
  ],
  templateUrl: './book.html',
  styleUrls: ['./book.css']
})
export class BookComponent implements OnInit, OnDestroy {
  books: Book[] = [];
  private bookSubscription!: Subscription;

  constructor(private dataService: DataService) {}

  ngOnInit(): void {
    // Mock data since we don't have a real API
    this.books = [
      {
        id: 1,
        title: 'Angular in Action',
        price: 499,
        publicationDate: '2023-05-15',
        description: 'A comprehensive guide to Angular development covering all modern features.'
      },
      {
        id: 2,
        title: 'TypeScript Essentials',
        price: 399,
        publicationDate: '2022-11-20',
        description: 'Master TypeScript to build robust web applications.'
      }
    ];

    // Actual API call would look like this:
    // this.bookSubscription = this.dataService.getBooks().subscribe({
    //   next: (data) => this.books = data,
    //   error: (err) => console.error('Error fetching books:', err)
    // });
  }

  ngOnDestroy(): void {
    if (this.bookSubscription) {
      this.bookSubscription.unsubscribe();
    }
  }
}